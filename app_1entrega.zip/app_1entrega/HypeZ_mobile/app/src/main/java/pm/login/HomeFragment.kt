package pm.login.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.viewpager2.widget.ViewPager2
import pm.login.R

class HomeFragment : Fragment() {

    private lateinit var viewPager: ViewPager2
    private lateinit var nextButton: Button

    // Lista de imagens a serem exibidas
    private val images = listOf(
        R.drawable.jakne1,  // imagem inicial
        R.drawable.wdress,
        R.drawable.kjakne
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootView = inflater.inflate(R.layout.fragment_home, container, false)

        // Configurações do ViewPager2
        viewPager = rootView.findViewById(R.id.viewPager)
        nextButton = rootView.findViewById(R.id.nextButton)

        val adapter = HomeAdapter(images)
        viewPager.adapter = adapter

        // Lógica para avançar para a próxima imagem
        nextButton.setOnClickListener {
            val nextItem = (viewPager.currentItem + 1) % images.size
            viewPager.setCurrentItem(nextItem, true)
        }

        return rootView
    }
}
