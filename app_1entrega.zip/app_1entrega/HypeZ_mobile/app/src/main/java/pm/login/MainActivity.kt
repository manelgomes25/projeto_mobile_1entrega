package pm.login

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import pm.login.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        // Verificar se o login foi salvo nas SharedPreferences
        val sharedPreferences = getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean("login", false)

        if (isLoggedIn) {
            // Se o usuário já fez login, redirecionar diretamente para a DashboardActivity
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }
    }

    fun doLogin(view: View) {
        // Instanciar a RequestQueue
        val queue = Volley.newRequestQueue(this)
        val url = "https://esan-tesp-ds-paw.web.ua.pt/tesp-ds-g33/api/ficheiro.php"

        // Criar uma nova StringRequest
        val postRequest = object : StringRequest(Method.POST, url,
            { response ->
                Log.d("Raw Response", response)
                var msg = response
                if (response == "OK") {
                    // do login...
                    if (binding.checkGuardar.isChecked) {
                        // guardar em SharedPreference o login
                        getSharedPreferences("pmLogin", Context.MODE_PRIVATE)
                            .edit()
                            .putBoolean("login", true)
                            .putString("email", binding.txtEmail.text.toString())
                            .apply()
                        msg += " + SAVE"
                    }
                    // Redirecionar para a DashboardActivity
                    startActivity(Intent(this, DashboardActivity::class.java))
                    finish()
                }
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            },
            Response.ErrorListener { error ->
                // Tratar erro
                Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()
                Log.d("Error.Response", error.toString())
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params: MutableMap<String, String> = HashMap()
                params["email"] = binding.txtEmail.text.toString()
                params["password"] = binding.txtPassword.text.toString()
                return params
            }
        }
        // Adicionar a solicitação à RequestQueue
        queue.add(postRequest)
    }
}
